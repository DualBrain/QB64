The HTML file is saved in C:\name_you_specified.html

The modern Windows version for the file may be found at www.freewebs.com/teamerx/newsite/htmlgen.exe

This software may not be distributed under any other name without consent of the author

Contact me at qbfreak2000@hotmail.com for questions/comments

Enjoy!