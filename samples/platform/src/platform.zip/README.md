# Platform

What does a 2D platform game take?

Made with QB64.
