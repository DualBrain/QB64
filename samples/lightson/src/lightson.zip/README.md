# LightsOn
A game written in QB64

<img src="screenshot.png">

<img src="screenshot2.png">

<img src="screenshot3.png">