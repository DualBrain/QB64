# cant-contain-me
Can't Contain Me is a game developed in QB64

The pieces are trying to escape your screen and the container that'll hold them back from leaving is in the center of the window. Drag as many fugitives as you can into the cell (even multiple at once) so you can win.

<img src="https://github.com/FellippeHeitor/cant-contain-me/blob/master/Screenshot1.JPG">
