# Set fire to the rain

It's raining and you must make fire. All you got are pixels on your screen to rub together in an attempt to achieve your goal.

How fast can you set fire to the rain?

Use your mouse and try to beat the clock.

'M' to mute the music.