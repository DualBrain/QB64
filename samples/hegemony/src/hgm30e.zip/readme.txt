Hegemony 3.0.e was written in QuickBasic which runs under DOS. This makes the program DOS-depending, even in the "exe" form, and even if you run it from Windows. The program requires that it is placed in a directory (folder) of your PC, containing no longer names than 8 characters.

Example:
C:\games\turnbasedstrategy\hegemony30e  -> WRONG!!!
C:\games\tbs\hegem30e                   -> POSSIBLE

As far as I know this is the only thing that can cause the game "freeze" (BSOD). Let me know if you find other bugs as well. 
 

Akos Ivanyi
ivanyiakos@hotmail.com
www.angelfire.com/ego/akos