# QDigger
A clone of DIGGER game in QuickBASIC

| Filename     |  Description                   |
|-------------:|:-------------------------------|
| QDIGGER.BAS  | SCREEN 1 version               |
| QDIGGERE.BAS | SCREEN 9 version               |
| ARCTIC.BAS   | Arctic Mine, Christmas version |
| MKLEV.BAS    | Level generator utility        |

![QDigger screenshot](./qdigger_screenshot.png)
![Arctic Mine screenshot](./arcticmine_screenshot.png)
