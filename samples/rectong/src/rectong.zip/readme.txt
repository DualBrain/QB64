Rectong v1.0 by Mike Chambers
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

Just a fun little game I wrote in QuickBasic one night.

All the control instructions can be found within the game!
You can play 1 player against computer AI, or 2 player
with a friend.

Enjoy, and please send me your feedback at: half_eaten@yahoo.com

-Mike Chambers
P.S. QuickBasic source is included.